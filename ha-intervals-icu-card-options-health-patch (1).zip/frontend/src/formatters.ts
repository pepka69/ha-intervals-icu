const ACTIVITY_TYPE_LABELS: Record<string, string> = {
  AlpineSki: "Ski alpin",
  BackcountrySki: "Ski de randonnée",
  Badminton: "Badminton",
  Basketball: "Basket-ball",
  Canoeing: "Canoë",
  Crossfit: "CrossFit",
  CrossFit: "CrossFit",
  Cycling: "Vélo",
  Elliptical: "Vélo elliptique",
  GravelRide: "Gravel",
  Handcycle: "Handbike",
  HighIntensityIntervalTraining: "HIIT",
  Hike: "Randonnée",
  IndoorCycling: "Vélo d’intérieur",
  IndoorRide: "Vélo d’intérieur",
  IndoorRun: "Course en intérieur",
  Kayaking: "Kayak",
  MountainBikeRide: "VTT",
  NordicSki: "Ski de fond",
  OpenWaterSwim: "Natation en eau libre",
  Pilates: "Pilates",
  Ride: "Vélo",
  RoadBikeRide: "Vélo de route",
  Rowing: "Aviron",
  Run: "Course à pied",
  Running: "Course à pied",
  Snowboard: "Snowboard",
  Soccer: "Football",
  StairStepper: "Escalier",
  StrengthTraining: "Musculation",
  Swim: "Natation",
  Swimming: "Natation",
  Tennis: "Tennis",
  TrailRun: "Trail",
  VirtualRide: "Vélo virtuel",
  VirtualRun: "Course virtuelle",
  Walk: "Marche",
  Walking: "Marche",
  WeightTraining: "Musculation",
  Workout: "Entraînement",
  Yoga: "Yoga"
};

export function formatDuration(
  rawValue: string | number | undefined | null
): string {
  if (
    rawValue === undefined ||
    rawValue === null ||
    rawValue === "" ||
    rawValue === "unknown" ||
    rawValue === "unavailable" ||
    rawValue === "none"
  ) {
    return "—";
  }

  const totalSeconds = Math.max(0, Math.round(Number(rawValue)));
  if (!Number.isFinite(totalSeconds)) return "—";

  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours === 0) {
    if (minutes === 0) return `${seconds} s`;
    if (seconds === 0) return `${minutes} min`;
    return `${minutes} min ${seconds} s`;
  }

  return `${hours} h ${String(minutes).padStart(2, "0")} min ${String(
    seconds
  ).padStart(2, "0")} s`;
}

export function translateActivityType(
  rawType: string | undefined | null
): string {
  if (!rawType || ["unknown", "unavailable", "none"].includes(rawType)) {
    return "Activité";
  }

  if (ACTIVITY_TYPE_LABELS[rawType]) {
    return ACTIVITY_TYPE_LABELS[rawType];
  }

  const normalized = rawType
    .replace(/[_-]+/g, " ")
    .replace(/([a-zà-ÿ0-9])([A-Z])/g, "$1 $2")
    .trim();

  return normalized
    ? normalized.charAt(0).toUpperCase() + normalized.slice(1).toLowerCase()
    : "Activité";
}
