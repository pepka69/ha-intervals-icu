import { LitElement, html, nothing } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { cardStyles } from "./styles";
import {
  DEFAULT_KEYS,
  deviceName,
  formatState,
  getState,
  historyValues,
  numericValue,
  relativeTime
} from "./entities";
import {
  formatDuration,
  translateActivityType
} from "./formatters";
import { gauge, historyChart } from "./graph";
import type {
  CardConfig,
  HassEntity,
  HomeAssistant
} from "./types";
import "./editor";

@customElement("ha-intervals-icu-card")
export class HaIntervalsIcuCard extends LitElement {
  static styles = cardStyles;

  @property({ attribute: false }) public hass?: HomeAssistant;
  @state() private config?: CardConfig;

  static getConfigElement() {
    return document.createElement("ha-intervals-icu-card-editor");
  }

  static getStubConfig(): Omit<CardConfig, "type"> {
    return {
      title: "Intervals.icu",
      layout: "standard",
      show_metrics: true,
      show_weekly_stats: true,
      show_records: true,
      show_history: true,
      show_workout: false,
      show_tomorrow_workout: false,
      show_last_activity: true,
      show_health: true,
      show_sync_status: true,
      show_weight: true,
      show_resting_hr: true,
      show_sleep: true,
      show_hrv: false,
      show_body_fat: false,
      show_vo2max: false
    };
  }

  public setConfig(config: CardConfig): void {
    if (!config) throw new Error("Configuration manquante");

    this.config = {
      layout: "standard",
      show_metrics: true,
      show_weekly_stats: true,
      show_records: true,
      show_history: true,
      show_workout: false,
      show_tomorrow_workout: false,
      show_last_activity: true,
      show_health: true,
      show_sync_status: true,
      show_weight: true,
      show_resting_hr: true,
      show_sleep: true,
      show_hrv: false,
      show_body_fat: false,
      show_vo2max: false,
      ...config
    };
  }

  public getCardSize(): number {
    return this.config?.layout === "compact" ? 5 : 10;
  }

  public getGridOptions() {
    return {
      columns: 12,
      min_columns: 6,
      rows: this.config?.layout === "compact" ? 5 : 9,
      min_rows: 4
    };
  }

  private state(
    field: keyof CardConfig,
    key: string
  ): HassEntity | undefined {
    return this.hass
      ? getState(
          this.hass,
          this.config?.[field] as string | undefined,
          key,
          this.config?.device_id
        )
      : undefined;
  }

  private customOrIntervalsState(
    configured: string | undefined,
    key: string
  ): HassEntity | undefined {
    if (!this.hass) return undefined;

    if (configured && this.hass.states[configured]) {
      return this.hass.states[configured];
    }

    return getState(
      this.hass,
      undefined,
      key,
      this.config?.device_id
    );
  }

  private status(
    metric: "fitness" | "fatigue" | "form",
    state?: HassEntity
  ): "good" | "warning" | "danger" | "neutral" {
    const value = numericValue(state);
    if (value === null) return "neutral";

    if (metric === "form") {
      return value < -20
        ? "danger"
        : value < -10
          ? "warning"
          : "good";
    }

    if (metric === "fatigue") {
      return value >= 80
        ? "danger"
        : value >= 60
          ? "warning"
          : "good";
    }

    return "good";
  }

  private metric(
    label: string,
    shortLabel: string,
    metric: "fitness" | "fatigue" | "form",
    state?: HassEntity
  ) {
    const value = numericValue(state);
    const status = this.status(metric, state);
    const min = metric === "form" ? -30 : 0;
    const max = metric === "form" ? 30 : 100;
    const change = state?.attributes.change_7_days;

    return html`
      <article class="metric ${metric}">
        <div class="metric-label">${label}</div>
        <div class="metric-value">
          ${formatState(this.hass!, state)}
        </div>
        <div class="metric-short">${shortLabel}</div>
        ${gauge(value, status, min, max)}
        <div class="metric-foot">
          7 j
          ${typeof change === "number"
            ? `${change > 0 ? "+" : ""}${change.toFixed(1)}`
            : "—"}
        </div>
      </article>
    `;
  }

  private infoRow(
    icon: string,
    label: string,
    state?: HassEntity
  ) {
    if (!state) return nothing;

    return html`
      <div class="info-row">
        <ha-icon icon=${icon}></ha-icon>
        <span>${label}</span>
        <strong>${formatState(this.hass!, state)}</strong>
      </div>
    `;
  }

  private healthItem(
    icon: string,
    label: string,
    state: HassEntity | undefined,
    enabled: boolean | undefined
  ) {
    if (enabled === false || !state) return nothing;

    return html`
      <div class="health-item">
        <ha-icon icon=${icon}></ha-icon>
        <div>
          <span>${label}</span>
          <strong>${formatState(this.hass!, state)}</strong>
        </div>
      </div>
    `;
  }

  protected render() {
    if (!this.hass || !this.config) return nothing;

    const hass = this.hass;
    const deviceId = this.config.device_id;

    const fitness = this.state(
      "fitness_entity",
      DEFAULT_KEYS.fitness
    );
    const fatigue = this.state(
      "fatigue_entity",
      DEFAULT_KEYS.fatigue
    );
    const form = this.state(
      "form_entity",
      DEFAULT_KEYS.form
    );
    const ftp = this.state(
      "ftp_entity",
      DEFAULT_KEYS.ftp
    );
    const weeklyLoad = this.state(
      "weekly_load_entity",
      DEFAULT_KEYS.weeklyLoad
    );
    const weeklyActivities = this.state(
      "weekly_activities_entity",
      DEFAULT_KEYS.weeklyActivities
    );

    const selectedDevice = deviceId
      ? hass.devices?.[deviceId]
      : undefined;
    const athleteLabel =
      this.config.athlete_name || deviceName(selectedDevice);

    const workout = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTodayName,
      deviceId
    );
    const workoutSport = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTodaySport,
      deviceId
    );
    const workoutDuration = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTodayDuration,
      deviceId
    );
    const workoutLoad = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTodayLoad,
      deviceId
    );

    const tomorrowWorkout = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTomorrowName,
      deviceId
    );
    const tomorrowSport = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTomorrowSport,
      deviceId
    );
    const tomorrowDuration = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTomorrowDuration,
      deviceId
    );
    const tomorrowLoad = getState(
      hass,
      undefined,
      DEFAULT_KEYS.plannedTomorrowLoad,
      deviceId
    );

    const last = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityName,
      deviceId
    );
    const lastType = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityType,
      deviceId
    );
    const lastDate = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityDate,
      deviceId
    );
    const lastDuration = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityDuration,
      deviceId
    );
    const lastLoad = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityLoad,
      deviceId
    );
    const lastCalories = getState(
      hass,
      undefined,
      DEFAULT_KEYS.lastActivityCalories,
      deviceId
    );

    const weight = this.customOrIntervalsState(
      this.config.weight_entity,
      DEFAULT_KEYS.weight
    );
    const restingHr = this.customOrIntervalsState(
      this.config.resting_hr_entity,
      DEFAULT_KEYS.restingHr
    );
    const sleep = this.customOrIntervalsState(
      this.config.sleep_entity,
      DEFAULT_KEYS.sleep
    );
    const hrv = this.customOrIntervalsState(
      this.config.hrv_entity,
      DEFAULT_KEYS.hrv
    );
    const bodyFat = this.customOrIntervalsState(
      this.config.body_fat_entity,
      DEFAULT_KEYS.bodyFat
    );
    const vo2max = this.customOrIntervalsState(
      this.config.vo2max_entity,
      DEFAULT_KEYS.vo2max
    );

    const sync = relativeTime(
      fitness?.last_updated ?? fitness?.last_changed
    );

    const healthHasData = [
      this.config.show_weight !== false ? weight : undefined,
      this.config.show_resting_hr !== false
        ? restingHr
        : undefined,
      this.config.show_sleep !== false ? sleep : undefined,
      this.config.show_hrv !== false ? hrv : undefined,
      this.config.show_body_fat !== false
        ? bodyFat
        : undefined,
      this.config.show_vo2max !== false
        ? vo2max
        : undefined
    ].some(Boolean);

    return html`
      <ha-card class=${`layout-${this.config.layout ?? "standard"}`}>
        <div class="card-shell">
          <header class="header">
            <div class="identity">
              <div class="logo">
                <ha-icon
                  icon="mdi:chart-timeline-variant-shimmer"
                ></ha-icon>
              </div>
              <div>
                <h2>${this.config.title ?? "Intervals.icu"}</h2>
                ${athleteLabel
                  ? html`
                      <div class="athlete">${athleteLabel}</div>
                    `
                  : nothing}
              </div>
            </div>

            ${this.config.show_sync_status !== false
              ? html`
                  <div class="sync">
                    <span class="dot ${sync.level}"></span>
                    ${sync.label}
                  </div>
                `
              : nothing}
          </header>

          ${this.config.show_metrics !== false
            ? html`
                <section class="metrics">
                  ${this.metric(
                    "FITNESS",
                    "CTL",
                    "fitness",
                    fitness
                  )}
                  ${this.metric(
                    "FATIGUE",
                    "ATL",
                    "fatigue",
                    fatigue
                  )}
                  ${this.metric(
                    "FORME",
                    "TSB",
                    "form",
                    form
                  )}
                </section>
              `
            : nothing}

          ${this.config.show_weekly_stats !== false
            ? html`
                <section class="quick-stats">
                  <div>
                    <span>FTP</span>
                    <strong>${formatState(hass, ftp)}</strong>
                  </div>
                  <div>
                    <span>Charge 7 j</span>
                    <strong>
                      ${formatState(hass, weeklyLoad)}
                    </strong>
                  </div>
                  <div>
                    <span>Activités 7 j</span>
                    <strong>
                      ${formatState(hass, weeklyActivities)}
                    </strong>
                  </div>
                </section>
              `
            : nothing}

          ${this.config.show_history !== false
            ? html`
                <section class="section chart-section">
                  <div class="section-title">
                    <ha-icon icon="mdi:chart-line"></ha-icon>
                    <span>Évolution</span>
                  </div>
                  ${historyChart([
                    {
                      label: "Fitness",
                      values: historyValues(fitness),
                      className: "fitness-line"
                    },
                    {
                      label: "Fatigue",
                      values: historyValues(fatigue),
                      className: "fatigue-line"
                    },
                    {
                      label: "Forme",
                      values: historyValues(form),
                      className: "form-line"
                    }
                  ])}
                </section>
              `
            : nothing}

          ${this.config.show_health !== false && healthHasData
            ? html`
                <section class="section health-section">
                  <div class="section-title">
                    <ha-icon icon="mdi:heart-pulse"></ha-icon>
                    <span>Santé</span>
                  </div>
                  <div class="health-grid">
                    ${this.healthItem(
                      "mdi:scale-bathroom",
                      "Poids",
                      weight,
                      this.config.show_weight
                    )}
                    ${this.healthItem(
                      "mdi:heart-pulse",
                      "FC au repos",
                      restingHr,
                      this.config.show_resting_hr
                    )}
                    ${this.healthItem(
                      "mdi:sleep",
                      "Sommeil",
                      sleep,
                      this.config.show_sleep
                    )}
                    ${this.healthItem(
                      "mdi:heart-flash",
                      "HRV",
                      hrv,
                      this.config.show_hrv
                    )}
                    ${this.healthItem(
                      "mdi:percent-outline",
                      "Masse grasse",
                      bodyFat,
                      this.config.show_body_fat
                    )}
                    ${this.healthItem(
                      "mdi:lungs",
                      "VO₂max",
                      vo2max,
                      this.config.show_vo2max
                    )}
                  </div>
                </section>
              `
            : nothing}

          <section class="lower-grid">
            ${this.config.show_workout !== false
              ? html`
                  <article class="feature workout">
                    <div class="section-title">
                      <ha-icon
                        icon="mdi:calendar-today"
                      ></ha-icon>
                      <span>Aujourd’hui</span>
                    </div>
                    <h3>
                      ${formatState(
                        hass,
                        workout,
                        "Aucun entraînement planifié"
                      )}
                    </h3>
                    <div class="pill">
                      ${translateActivityType(workoutSport?.state)}
                    </div>
                    <div class="feature-meta">
                      <span>
                        <ha-icon
                          icon="mdi:clock-outline"
                        ></ha-icon>
                        ${formatDuration(workoutDuration?.state)}
                      </span>
                      <span>
                        <ha-icon
                          icon="mdi:chart-bar"
                        ></ha-icon>
                        Charge ${formatState(hass, workoutLoad)}
                      </span>
                    </div>
                  </article>
                `
              : nothing}

            ${this.config.show_tomorrow_workout !== false
              ? html`
                  <article class="feature workout">
                    <div class="section-title">
                      <ha-icon
                        icon="mdi:calendar-arrow-right"
                      ></ha-icon>
                      <span>Demain</span>
                    </div>
                    <h3>
                      ${formatState(
                        hass,
                        tomorrowWorkout,
                        "Aucun entraînement planifié"
                      )}
                    </h3>
                    <div class="pill">
                      ${translateActivityType(tomorrowSport?.state)}
                    </div>
                    <div class="feature-meta">
                      <span>
                        <ha-icon
                          icon="mdi:clock-outline"
                        ></ha-icon>
                        ${formatDuration(tomorrowDuration?.state)}
                      </span>
                      <span>
                        <ha-icon
                          icon="mdi:chart-bar"
                        ></ha-icon>
                        Charge ${formatState(hass, tomorrowLoad)}
                      </span>
                    </div>
                  </article>
                `
              : nothing}

            ${this.config.show_records !== false
              ? html`
                  <article class="feature records-card">
                    <div class="section-title">
                      <ha-icon
                        icon="mdi:trophy-outline"
                      ></ha-icon>
                      <span>Records</span>
                    </div>
                    ${this.infoRow(
                      "mdi:bike-fast",
                      "FTP",
                      getState(
                        hass,
                        undefined,
                        DEFAULT_KEYS.recordFtp,
                        deviceId
                      )
                    )}
                    ${this.infoRow(
                      "mdi:map-marker-distance",
                      "Distance",
                      getState(
                        hass,
                        undefined,
                        DEFAULT_KEYS.recordDistance,
                        deviceId
                      )
                    )}
                    ${this.infoRow(
                      "mdi:image-filter-hdr",
                      "Dénivelé",
                      getState(
                        hass,
                        undefined,
                        DEFAULT_KEYS.recordElevation,
                        deviceId
                      )
                    )}
                    ${this.infoRow(
                      "mdi:flash",
                      "Puissance max",
                      getState(
                        hass,
                        undefined,
                        DEFAULT_KEYS.recordMaxPower,
                        deviceId
                      )
                    )}
                  </article>
                `
              : nothing}

            ${this.config.show_last_activity !== false
              ? html`
                  <article class="feature last-activity">
                    <div class="section-title">
                      <ha-icon icon="mdi:history"></ha-icon>
                      <span>Dernière activité</span>
                    </div>
                    <h3>${formatState(hass, last)}</h3>
                    <div class="pill purple">
                      ${translateActivityType(lastType?.state)}
                    </div>
                    <div class="activity-details">
                      <span>
                        <ha-icon
                          icon="mdi:calendar-blank-outline"
                        ></ha-icon>
                        ${formatState(hass, lastDate)}
                      </span>
                      <span>
                        <ha-icon
                          icon="mdi:clock-outline"
                        ></ha-icon>
                        ${formatDuration(lastDuration?.state)}
                      </span>
                      <span>
                        <ha-icon icon="mdi:fire"></ha-icon>
                        ${formatState(hass, lastCalories)}
                      </span>
                      <span>
                        <ha-icon
                          icon="mdi:chart-bar"
                        ></ha-icon>
                        Charge ${formatState(hass, lastLoad)}
                      </span>
                    </div>
                  </article>
                `
              : nothing}
          </section>
        </div>
      </ha-card>
    `;
  }
}
