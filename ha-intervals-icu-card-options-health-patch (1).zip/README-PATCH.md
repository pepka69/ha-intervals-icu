# Options de carte et capteurs personnalisés

Ce patch regroupe :
- formatage lisible des durées ;
- traduction française des types d'activités ;
- sections affichables/masquables ;
- profils Compact, Standard et Complet ;
- entraînement d'aujourd'hui et de demain optionnels ;
- bloc Santé configurable ;
- capteurs personnalisés pour poids, FC au repos, sommeil, HRV, masse grasse et VO₂max ;
- priorité au capteur manuel, puis détection automatique Intervals.icu.
