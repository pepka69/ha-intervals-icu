import { LitElement, html } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { cardStyles } from "./styles";
import {
  DEFAULT_KEYS,
  deviceName,
  findEntity,
  integrationDevices
} from "./entities";
import type {
  CardConfig,
  CardLayout,
  HomeAssistant
} from "./types";

const automaticFields: Array<[keyof CardConfig, string, string]> = [
  ["fitness_entity", "Fitness", DEFAULT_KEYS.fitness],
  ["fatigue_entity", "Fatigue", DEFAULT_KEYS.fatigue],
  ["form_entity", "Forme", DEFAULT_KEYS.form],
  ["ftp_entity", "FTP", DEFAULT_KEYS.ftp],
  ["weekly_load_entity", "Charge 7 jours", DEFAULT_KEYS.weeklyLoad],
  [
    "weekly_activities_entity",
    "Activités 7 jours",
    DEFAULT_KEYS.weeklyActivities
  ]
];

const customHealthFields: Array<
  [keyof CardConfig, string, string, keyof CardConfig]
> = [
  ["weight_entity", "Capteur de poids", "weight", "show_weight"],
  [
    "resting_hr_entity",
    "Capteur de FC au repos",
    "resting_hr",
    "show_resting_hr"
  ],
  ["sleep_entity", "Capteur de sommeil", "sleep", "show_sleep"],
  ["hrv_entity", "Capteur HRV", "hrv", "show_hrv"],
  [
    "body_fat_entity",
    "Capteur de masse grasse",
    "body_fat",
    "show_body_fat"
  ],
  ["vo2max_entity", "Capteur VO₂max", "vo2max", "show_vo2max"]
];

const entityOverrideFields: Array<keyof CardConfig> = [
  ...automaticFields.map(([field]) => field),
];

const sectionToggles: Array<[keyof CardConfig, string]> = [
  ["show_metrics", "Afficher Fitness / Fatigue / Forme"],
  ["show_weekly_stats", "Afficher les statistiques 7 jours"],
  ["show_history", "Afficher le graphique d’évolution"],
  ["show_workout", "Afficher l’entraînement du jour"],
  ["show_tomorrow_workout", "Afficher l’entraînement de demain"],
  ["show_records", "Afficher les records"],
  ["show_last_activity", "Afficher la dernière activité"],
  ["show_health", "Afficher le bloc Santé"],
  ["show_sync_status", "Afficher l’état de synchronisation"]
];

const layoutDefaults: Record<CardLayout, Partial<CardConfig>> = {
  compact: {
    show_metrics: true,
    show_weekly_stats: true,
    show_history: false,
    show_workout: false,
    show_tomorrow_workout: false,
    show_records: false,
    show_last_activity: true,
    show_health: false,
    show_sync_status: true
  },
  standard: {
    show_metrics: true,
    show_weekly_stats: true,
    show_history: true,
    show_workout: false,
    show_tomorrow_workout: false,
    show_records: true,
    show_last_activity: true,
    show_health: true,
    show_sync_status: true
  },
  complete: {
    show_metrics: true,
    show_weekly_stats: true,
    show_history: true,
    show_workout: true,
    show_tomorrow_workout: true,
    show_records: true,
    show_last_activity: true,
    show_health: true,
    show_sync_status: true
  }
};

@customElement("ha-intervals-icu-card-editor")
export class IntervalsIcuCardEditor extends LitElement {
  static styles = cardStyles;

  @property({ attribute: false }) public hass?: HomeAssistant;
  @state() private config?: CardConfig;

  public setConfig(config: CardConfig): void {
    this.config = { ...config };
  }

  private emitConfig(config: CardConfig): void {
    this.config = config;
    this.dispatchEvent(
      new CustomEvent("config-changed", {
        detail: { config },
        bubbles: true,
        composed: true
      })
    );
  }

  private change(
    field: keyof CardConfig,
    value: string | boolean | undefined
  ): void {
    const config = { ...this.config! };
    if (value === "" || value === undefined) {
      delete config[field];
    } else {
      Object.assign(config, { [field]: value });
    }
    this.emitConfig(config);
  }

  private changeDevice(deviceId: string): void {
    const config = {
      ...this.config!,
      device_id: deviceId || undefined
    };
    for (const field of entityOverrideFields) {
      delete config[field];
    }
    this.emitConfig(config);
  }

  private changeLayout(layout: CardLayout): void {
    this.emitConfig({
      ...this.config!,
      layout,
      ...layoutDefaults[layout]
    });
  }

  private entityOptions(
    sensorIds: string[],
    selected: string | undefined,
    automaticLabel: string
  ) {
    return html`
      <option value="">${automaticLabel}</option>
      ${sensorIds.map(
        (id) => html`
          <option value=${id} ?selected=${selected === id}>
            ${this.hass!.states[id].attributes.friendly_name ?? id}
          </option>
        `
      )}
    `;
  }

  protected render() {
    if (!this.config || !this.hass) return html``;

    const devices = integrationDevices(this.hass);
    const selectedDeviceId =
      this.config.device_id ??
      (devices.length === 1 ? devices[0].id : "");

    const athleteSensorIds = Object.keys(this.hass.states)
      .filter(
        (id) =>
          id.startsWith("sensor.") &&
          (!selectedDeviceId ||
            this.hass!.entities?.[id]?.device_id === selectedDeviceId)
      )
      .sort();

    const allSensorIds = Object.keys(this.hass.states)
      .filter((id) => id.startsWith("sensor."))
      .sort();

    return html`
      <div class="editor">
        <div class="editor-group">
          <h3>Général</h3>

          <label>
            Athlète / appareil
            <select
              .value=${selectedDeviceId}
              @change=${(event: Event) =>
                this.changeDevice(
                  (event.target as HTMLSelectElement).value
                )}
            >
              <option value="">Sélectionner un athlète</option>
              ${devices.map(
                (device) => html`
                  <option value=${device.id}>
                    ${deviceName(device)}
                  </option>
                `
              )}
            </select>
          </label>

          <label>
            Titre
            <input
              .value=${this.config.title ?? "Intervals.icu"}
              @change=${(event: Event) =>
                this.change(
                  "title",
                  (event.target as HTMLInputElement).value
                )}
            />
          </label>

          <label>
            Nom affiché
            <input
              .value=${this.config.athlete_name ?? ""}
              placeholder="Nom de l’appareil par défaut"
              @change=${(event: Event) =>
                this.change(
                  "athlete_name",
                  (event.target as HTMLInputElement).value
                )}
            />
          </label>

          <label>
            Présentation
            <select
              .value=${this.config.layout ?? "standard"}
              @change=${(event: Event) =>
                this.changeLayout(
                  (event.target as HTMLSelectElement).value as CardLayout
                )}
            >
              <option value="compact">Compacte</option>
              <option value="standard">Standard</option>
              <option value="complete">Complète</option>
            </select>
          </label>
        </div>

        <div class="editor-group">
          <h3>Sections affichées</h3>
          ${sectionToggles.map(
            ([field, label]) => html`
              <label class="check">
                <input
                  type="checkbox"
                  .checked=${this.config![field] !== false}
                  @change=${(event: Event) =>
                    this.change(
                      field,
                      (event.target as HTMLInputElement).checked
                    )}
                />
                ${label}
              </label>
            `
          )}
        </div>

        <div class="editor-group">
          <h3>Capteurs Intervals.icu</h3>
          ${automaticFields.map(
            ([field, label, key]) => html`
              <label>
                ${label}
                <select
                  .value=${String(
                    this.config![field] ??
                      findEntity(
                        this.hass!,
                        undefined,
                        key,
                        selectedDeviceId
                      ) ??
                      ""
                  )}
                  @change=${(event: Event) =>
                    this.change(
                      field,
                      (event.target as HTMLSelectElement).value
                    )}
                >
                  ${this.entityOptions(
                    athleteSensorIds,
                    this.config![field] as string | undefined,
                    "Détection automatique pour cet athlète"
                  )}
                </select>
              </label>
            `
          )}
        </div>

        <div class="editor-group">
          <h3>Santé et capteurs personnalisés</h3>
          <p class="editor-help">
            Un capteur choisi ici remplace la donnée Intervals.icu.
            Tu peux donc utiliser ta balance, Garmin, Withings ou
            n’importe quel capteur Home Assistant.
          </p>

          ${customHealthFields.map(
            ([field, label, _key, toggle]) => html`
              <label class="check">
                <input
                  type="checkbox"
                  .checked=${this.config![toggle] !== false}
                  @change=${(event: Event) =>
                    this.change(
                      toggle,
                      (event.target as HTMLInputElement).checked
                    )}
                />
                Afficher ${label.replace("Capteur de ", "").replace("Capteur ", "")}
              </label>

              <label>
                ${label}
                <select
                  .value=${String(this.config![field] ?? "")}
                  @change=${(event: Event) =>
                    this.change(
                      field,
                      (event.target as HTMLSelectElement).value
                    )}
                >
                  ${this.entityOptions(
                    allSensorIds,
                    this.config![field] as string | undefined,
                    "Détection automatique Intervals.icu"
                  )}
                </select>
              </label>
            `
          )}
        </div>
      </div>
    `;
  }
}
